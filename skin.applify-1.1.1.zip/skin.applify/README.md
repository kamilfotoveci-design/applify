# Pyrus Skin v1.0.1

By kamilwhoo. Apple TV-inspired interface, configurable widgets and detailed Player Info. Tested by the maintainer on Kodi 22.

Install and update through https://kamilfotoveci-design.github.io/applify/

Previously named Applify. The existing skin ID is retained for updates and settings continuity. This 1.0.1 visual refresh still needs final on-device QA before its announcement.

See RELEASE-v1.0.1.md and the retained third-party licenses.
