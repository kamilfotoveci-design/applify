# Current release:1.3.5

See RELEASE-NOTES-1.3.5.md for the fixed player labels, adjacent larger Pause/Stop, matte grey dialogs, Home preservation and actual testing scope. Older notes below retain their historical scope; prior player text-fit assertions are superseded.

# Current release:1.3.4

See RELEASE-NOTES-1.3.4.md for the button-spacing audit, corrections and actual test limits. Earlier entries below retain their original scope.

# Current release 1.3.3

See RELEASE-NOTES-1.3.3.md and development/flat-ui-tests-1.3.3.json. Current changes/tests supersede the historical notes below. Target-box runtime remains unverified.

# Current release:1.3.2

See RELEASE-NOTES-1.3.2.md for current implementation, validation and limits. Earlier sections record prior builds.

# Current release:1.3.1

See RELEASE-NOTES-1.3.1.md for the complete-poster change and current testing scope. This release includes all1.3.0 player changes.

# Current release: 1.3.0

See RELEASE-NOTES-1.3.0.md for current changes, installation, validation and limits. Earlier sections below describe historical releases; their runtime results do not certify this build.

# Applify 1.2.9 — shelf spacing and flat Add-ons

## Current release — 1.2.9

- Shelf headings use a dedicated 28px SF Pro/Inter font with a 40px reserved area. Card containers start at y68 within each row, up from y45. Landscape/poster row heights are 276/456px, retaining the safe focused viewport. The conservative focus-zoom model leaves at least 24px between the heading area and artwork.
- The old rectangular More pill is replaced by a 76px circular chevron with **See All** underneath. Its circle center matches the artwork center for both landscape and poster rows. Native IDs/actions/remote return links are retained; it opens the same source directory and its real provider pagination.
- **Add-ons opens one flat grid with no categories.** Enabled runnable video/music/picture/program add-ons are collected on entry, deduplicated by ID and sorted by name. There are twelve native card slots per page, with Previous/Next when needed and Refresh to re-read the installed catalog. Empty catalogs show a clear state. Each native item launches its validated installed ID through RunAddon; the native hub stays in window history for normal Back navigation. Live return behavior still requires box testing.
- No companion add-on, Python GUI loop or background service is added. Four local JSON-RPC queries happen on entry/Refresh; paging uses a cached catalog in window properties. Kodi owns the grid, icons, focus and launch actions. Existing widget sources, accounts, font files, playback and search routes are retained.

Install this ZIP over the previous release and restart Kodi. Verification: **124 XML files**, **115 spacing/alignment/control checks**, **98 catalog/pagination/focus checks**, the **219 layout/material checks and 69,984-position model**, **890 native FreeType/filename checks**, and **46 mocked helper/provider tests** pass. Current records are named 1.2.9 in development/. These are static, modeled, mocked and local font tests. A controlled spacing/material preview was inspected; the current Add-ons hub has not been executed in Kodi here. Actual app launching/return history, physical remote navigation, asynchronous property/thumbnail updates and ARM performance must still be checked on CoreELEC. Earlier unresolved stress-start limitations remain.

Current checks from this skin directory:

```
python3 development/validate_skin.py .
python3 development/test_shelves129.py .
python3 development/test_addons129.py .
python3 development/test_cinematic129.py .
python3 development/test_kodi_font_loader.py .
ORCHARD_TEST_ROOT=. python3 development/test_editor129.py
```

Earlier sections below retain their historical release scope and are not a current runtime certification.

## 1.2.8 current verification

219 static/layout/material checks pass, including static three-line synopsis budgets in all fontsets, optional captions, remote wrap links, focus-only material layers, reduced-mode endpoints, text insets, all eight list bounds and focus-zoom margins. The exhaustive steady-state model passes 69,984 forward/back focus positions across 6,561 hidden/landscape/poster arrangements, including the low first-landscape state. Records: development/cinematic-tests-1.2.8.json.

887 Kodi filename-gate/native FreeType checks pass for all current fontsets and both supplied SF Pro faces. The 123 XML files and include/font/texture/control/action references pass static validation. All six Home navigation click chains were compared with the prior verified actions and are unchanged. The 46 mocked editor/provider tests pass, including caption-preference persistence, unhiding and cancellation. They do not execute Kodi's menus.

Controlled layout/material previews use the actual packaged textures/fonts and synthetic flat artwork substitutes. They were visually inspected for the resting landscape composition, raised poster stage and final navigation material. An initial preview renderer used the wrong accumulated second-row height and compositing background; it was corrected. Those preview mistakes were not changes to Kodi's grouplist geometry. A too-wide elliptical edge in the new bar asset was found during review and replaced with a capsule edge before packaging.

This environment has no Kodi executable; native wrapped-label behavior was checked in Kodi Omega sources (GUILabel/GUITextLayout) and the .ttf gate in the user's CoreELEC revision. Real focus transitions, actual line advance/ellipsis on the box, physical overscan, HDR output, live providers, GPU frame pacing and extended stability remain unverified. The earlier stress-start crash remains unresolved. Historical tests below are not a runtime rerun of 1.2.8.

## 1.2.7 — missing text correction

Kodi's GUIFontManager::LoadFonts only registers Font.xml entries whose filename ends in `.ttf`. Version 1.2.6 incorrectly referenced `.otf` assets, so Kodi skipped those font definitions entirely and text disappeared. The two supplied SF Pro assets are now named `sf-pro-display-regular.ttf` and `sf-pro-display-semibold.ttf`; Font.xml references those exact lowercase paths. Their OpenType CFF data is byte-for-byte unchanged. This is filename normalization for Kodi's loader gate, not outline conversion. Kodi's underlying FreeType loader accepts these outlines.

The regression checks every fontset entry against Kodi's filename gate and loads/rasterizes both exact packaged faces through the local native FreeType library. XML/resource checks and the geometry model are also rerun. 878 filename-gate/native FreeType checks, 120 layout/action/font checks, 123 XML files and 69,984 modeled shelf positions passed. The same filename gate was verified in CoreELEC revision cfc215086edfe8b96de48530c5cdff1d2d78e92a. Full Kodi/CoreELEC runtime rendering is still unverified here. The Inter fontset remains available. Install the ZIP and restart Kodi. If the invisible UI blocks installation, apply the SSH recovery below first.

```
for f in /storage/.kodi/addons/skin.applify/fonts/*.otf; do
  [ -f "$f" ] && cp "$f" "${f%.otf}.ttf"
done
sed -i 's/\.otf</.ttf</g' /storage/.kodi/addons/skin.applify/xml/Font.xml
systemctl restart kodi
```

Historical 1.2.6 static and asset-preview results below missed this Kodi-specific gate; they did not demonstrate working runtime fonts.

Date: 20 October 2026. Release candidate; target CoreELEC validation is outstanding.

## 1.2.6 targeted typography verification

120 targeted static/layout/font/action checks passed (development/navigation-tests-1.2.6.json). They use the packaged SF Pro faces for navigation width checks and verify static outlines, English/Slovak/Czech glyphs, authentic weights without synthetic lighten/bold, no increase in line advance versus Inter, the two-line compact synopsis allowance, safe hero-title height and the intact Inter fallback fontset. A preview rendered from those exact OTFs and navigation PNGs was visually inspected in focused and inactive states. It is an asset preview, not a Kodi runtime screenshot.

All 123 XML files pass structural/resource/focus/action validation. The shelf model still passes 69,984 positions across 6,561 hidden/landscape/poster combinations. No widget/search/playback logic is changed in this typography release. Historical results below retain their version scope, rather than claiming a new runtime rerun.

The supplied static OTFs are byte-identical to the fonts extracted from the user's SF-Pro.dmg; hashes and sizes are in development/sfpro-fonts-1.2.6.json. SF Compact/Mono DMGs are not required. Switching fonts and actual FreeType rendering still need the user's CoreELEC box; there is no Kodi executable in this environment. This test does not resolve the prior stress-start issue or certify bug-free use. The two added fonts occupy 12,648,100 bytes uncompressed; actual ARM RSS and frame times were not measured.

Re-run static checks from the skin directory with:

```
python3 development/validate_skin.py .
python3 development/test_shelf_geometry.py .
python3 development/test_cinematic128.py .
```

The typography preview check requires Pillow and fontTools at build time only, not inside Kodi.

## 1.2.5 targeted verification

54 targeted static/layout/font/action tests passed (development/navigation-tests-1.2.5.json). They check native cell widths, all left/right wrap links, focus-only capsule visibility, content text insets, preservation of existing Home click action chains, dimming conditions, static font glyph coverage, safe compact synopsis bounds, centered context bounds/capped list, removal of the old 175px offset, scrolling text and guarded/encoded completion requests. A navigation preview was rendered from the actual packaged font and texture assets and inspected in focused and inactive states; this is not a native Kodi screenshot.

44 mocked editor/provider/synopsis tests pass, including long Unicode/newline synopsis preservation and the empty-text fallback. All 123 XML files and referenced assets/fonts pass validation. The 69,984-position shelf geometry model passes with the new 460–1020 focused viewport. The 53 banding asset/compositing checks remain valid.

Context origin behavior was checked against Kodi Omega GUIWindow::GetPosition and native context-menu sizing behavior. Optional completion API was checked from the official 2.1.2 source: autocomplete directory and selectautocomplete/Input.SendText handoff. The current environment still has no Kodi executable. New transitions, live completion, context scrolling/long labels and actual TV overscan need runtime testing on the user's device. Passing static checks do not certify a bug-free skin or resolve the previously documented stress-start issue.

## 1.2.4 targeted banding verification

53 asset, spectral, compositing and XML-layer checks pass; the JSON is development/banding-tests-1.2.4.json. They verify all seven native PNG assets, blue-noise mask properties, alpha accuracy, neutral grain, transparent/opaque edges, one custom gradient pass per affected screen and all PNG fallback references. Controlled synthetic composites were inspected visually. All 123 XML files pass static validation. The existing modeled shelf checks pass unchanged.

No Kodi executable is available in the current environment, so this release has not been executed in Kodi. All native Kodi checks below retain their historical version/scope. There is no new claim about target-device smoothness, actual HDMI gradients or resolved stress-start crashes. See BANDING-FIX.md.

## 1.2.2 targeted verification

Fourteen current native Kodi checks passed for default List, switching List/Landscape/Poster, retaining directory data, suppressing false empty states, saving/restoring the view after leaving, reading Home artwork from Settings, removed hero buttons and returning Home in reduced-animation mode. Eight additional checks passed for navigation directly from the top bar to the shelf, Info from a widget card, local fixture playback by selecting the card, playback OSD, audio settings, focus from the toolbar to the active Poster control, poster scrolling and Info from a poster card. Screenshots of all three views, the single navigation capsule, removed hero actions, poster scrolling, details and playback OSD were inspected. These are native offline-fixture checks in Kodi 20.5, not the user's CoreELEC build.

123 XML files pass static validation; 42 mocked editor/provider tests pass. The shelf geometry model still passes 69,984 focus positions across 6,561 visibility/layout combinations. POV 6.10.06 source inspection confirms sized artwork URLs in a metadata cache with a 30-day default lifetime and its supported metadata-clear route. The new refresh action has routing/missing-provider regression coverage; actual POV confirmation, remote metadata download and the user's final artwork sharpness still need target-box verification. No whole texture-cache deletion is performed.

Short native transitions load and remain navigable in the tested screens, and reduced mode returns correctly. ARM GPU frame pacing and physical TV animation smoothness have not been measured. Prior 1.2.1/1.2.0 records retain their original scope, including the unexplained stress-start failure below.

## 1.2.1 targeted verification

The removal regression was reproduced: the shelf was hidden, but its old fallback title remained in the editor. Eight real Kodi checks now verify removal and the immediate Empty Slot label. Six follow-up checks after process restart verify the cleared source, hidden row, persistent Empty Slot and Restore Default behavior. A separate two-check native fixture verifies that decorated display labels can be replaced by clean metadata titles.

Seventeen requested UI/search protocol checks passed in the final run. The protocol checks use an explicitly **offline routing fixture with the POV add-on ID**, not the real POV implementation or a connected account. They exercise the native Add-ons selector and launching, Movies/TV keyboard search, correctly encoded query handoff, local playback, More, real supplied Next Page links, POV preference saving and mixed poster/landscape navigation. Live POV scrapers, metadata services, authorized media access and TMDb Helper-to-POV player handoff still require the user's box. Do not describe these routing checks as live POV or Trakt testing.

Static validation and **40 mocked editor/search/provider regression tests** passed. Source protocol checks used the official POV 6.10.06 package and TMDb Helper nexus source. Actual screenshot inspection covers the complete focused first and third poster rows, the intervening landscape row and More focus. Higher-resolution POV preference saving is tested. Four additional real Kodi checks verify the 2160p cache limit, 1080p fallback image limit, backup of a pre-existing advancedsettings.xml and return to 1080p; cache merging and invalid-input preservation also have mocked regression coverage. A first native backup assertion incorrectly expected a backup when no original file existed; a second run with an existing file verified the backup. Physical 4K artwork rendering is not tested; target image sharpness, 4K output and download performance are not.

The earlier 1.2.0 runtime records below retain their original scope; they are not relabelled as a complete rerun of 1.2.1. The unresolved Kodi 20.5 stress-start limitation also remains.

## Execution environment

Actual Kodi 20.5 Linux x86_64 with a 1920×1080 Xvfb display, software OpenGL, a native offline video add-on and H.264/AAC sample playback. Only the disposable test copy lowered GUI API 5.17.0 to 5.16.0. A udev FD shim and null ALSA output were necessary in this environment. None are bundled as skin dependencies. Kodi 21 and 22 were checked at the API/source level, not executed here.

## Functional and restart tests

Thirty-five current functional checks and twelve subsequent restart/maintenance checks passed with two configured offline fixture rows per page. They cover separate page state, settings/editor, native playback, exclusive OSD/pause overlays, Player Info, audio/subtitle access, backup and restart persistence. The JSON records are included in development/runtime-main-1.2.0.json and runtime-restart-1.2.0.json. These passing runs do not override the stress-start failures below.

## Focused UI and performance audit

- Fourteen targeted runtime assertions passed in the audit recorded in development/runtime-audit-1.2.0.json. Eight directories each returning 300 items respected 10-item and 6-item widget caps. These directories reused ten local images; this is not a remote/network artwork benchmark.
- Thirty all-landscape page switches used zero Home XML reloads, retained their state and six-item limits. RSS rose from 289,800 to 329,388 KiB in that run. This short x86/software-rendering observation is neither an ARM memory measurement nor proof that memory use plateaus over hours.
- Final geometry-transition checks are recorded separately. Screenshots after the corrected transition show the entire selected poster card, rather than clipping it to a landscape viewport. Two-line titles and the compact player were visually inspected.
- Static validation parses 122 XML files and checks required windows/dependencies, resources, includes, variables, custom IDs and numeric focus links. Native page-action conditions are checked against dependencies on same-click mutations.
- Twenty-six stateful mocked editor tests passed. These are not Kodi runtime tests.
- A 69,984-position geometry model covers eight slots and 6,561 hidden/landscape/poster combinations; font-area assertions reserve 180px for two Noto 64 lines. This is a model, not actual remote execution.

## Failures found during development

The audit found a real transition bug: a later onclick condition read a property set by an earlier onclick. Kodi evaluates action conditions before executing the actions, so the required reload was delayed until the next click. Conditions now directly use the pre-click page/layout state; the old Home is hidden during geometry reload. A separate provider-visibility dependency could leave configured rows empty after reload; providers now stay alive based on their configured source rather than their own item count.

The extracted Kodi 20.5 runtime also crashed intermittently during cold starts with eight simultaneous 300-item Python fixture sources, including one run before the controller started. Earlier a native getHeight inspection of a wrapping textbox also crashed. Removing that inspection allowed the same UI flow to complete, but it does not explain every startup failure. Fixture references were explicitly released and redundant migration interpreters are now skipped after migration. **The stress-start crash root cause is not conclusively isolated. This build must not be described as crash-free or production-certified.**

Initial failures, subsequent passing runs and source-level checks are kept distinct; older 1.1.0 results are archived, not added to current totals. No whole-skin pixel identity or exhaustive audit of every inherited native dialog is claimed.

## Still required on the target device

Install/update and skin-switch recovery; physical remote; live Umbrella/Trakt lists; slow/offline add-ons; cold starts with the user's actual providers; extended overnight memory/frame-pacing checks; 4K scaling and overscan; HDR10/DV source profiles and output; physical FEL reconstruction and audio passthrough/Atmos. A native skin cannot guarantee the reliability or response time of a third-party provider.

## Technical Player Info source verification

CoreELEC's native extended labels were checked at revision cfc215086edfe8b96de48530c5cdff1d2d78e92a:

- https://github.com/CoreELEC/xbmc/blob/cfc215086edfe8b96de48530c5cdff1d2d78e92a/addons/skin.estuary/xml/DialogPlayerProcessInfo.xml
- https://github.com/CoreELEC/xbmc/blob/cfc215086edfe8b96de48530c5cdff1d2d78e92a/xbmc/GUIInfoManager.cpp

The local runtime verifies real H.264/AAC/decoder values and honest unavailable-platform fallbacks. Source FEL/MEL does not prove EL reconstruction. Codec/passthrough labels do not prove the receiver's final decoding mode.
