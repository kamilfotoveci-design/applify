# Applify v1.0.0

An Apple TV-inspired skin for Kodi, created by Kamil.

Features: cinematic home screens, configurable library/add-on widgets,
movie/TV information, search, clean playback controls and bundled SF Pro
Display typography. Default, Inter and multilingual Noto Sans fontsets ship
inside the package. Targets Kodi 21; Kodi 22 has not been runtime-tested.

Install skin.applify-1.0.0.zip in Kodi through Add-ons → Install from ZIP file.
Restart Kodi, select Applify, then set Settings → Interface → Skin → Fonts → Default.
Applify uses its own ID, skin.applify, and installs beside the older Orchard
skin. Export widgets from the old skin and import that JSON through Applify's
widget maintenance menu if you want to transfer the widget layout.

SF Pro Display Regular/Semibold are the supplied unchanged CFF/OTF files
with .ttf filenames for Kodi's font loader. All font and upstream code
license files are retained. This independent project is not affiliated with Apple.

Validation: XML/Python parsing, packaged font references and native FreeType
rendering. Full Kodi/CoreELEC runtime and live GitHub download were not tested.
